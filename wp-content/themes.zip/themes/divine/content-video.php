<?php

the_title();
the_content();
the_post_thumbnail();